package com.nvprototech.carromaim

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CarromAimApp() }
    }
}

private val woodDark = Color(0xFF75401F)
private val woodLight = Color(0xFFD9A66A)

@Composable
private fun CarromAimApp() {
    val engine = remember { CarromPhysics() }
    var power by remember { mutableFloatStateOf(.62f) }
    var angle by remember { mutableFloatStateOf(90f) }
    var running by remember { mutableStateOf(false) }
    var frame by remember { mutableIntStateOf(0) }
    var showPath by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf("Set direction and power, then simulate a shot.") }
    var traces by remember { mutableStateOf<List<List<Vec>>>(emptyList()) }

    LaunchedEffect(running) {
        while (running) {
            if (engine.isMoving()) {
                engine.step()
                frame++
                delay(16)
            } else {
                running = false
                message = "Simulation complete. Reset to try another shot."
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF54D7E5), background = Color(0xFF101719),
        surface = Color(0xFF1B2628)
    )) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF101719)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("CARROM AIM AI", color = Color(0xFF65DCE9),
                        fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Text("PHYSICS PRACTICE STUDIO", color = Color.LightGray, fontSize = 10.sp)
                }
                Text("OFFLINE", color = Color(0xFF78DDAA), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            CarromBoard(
                engine = engine, traces = traces, showPath = showPath,
                angle = angle, modifier = Modifier.fillMaxWidth().weight(1f)
            )

            Surface(color = Color(0xFF1B2628), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("SHOT CONTROLS", color = Color.White, fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f))
                        Text("ANGLE ${angle.toInt()}°", color = Color(0xFF65DCE9), fontSize = 11.sp)
                    }
                    Slider(value = angle, onValueChange = { angle = it }, valueRange = 0f..360f)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Power", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text("${(power * 100).toInt()}%", color = Color.White, fontSize = 12.sp)
                    }
                    Slider(value = power, onValueChange = { power = it }, valueRange = .05f..1f)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Show trajectories", color = Color.White, fontSize = 12.sp,
                            modifier = Modifier.weight(1f))
                        Switch(checked = showPath, onCheckedChange = { showPath = it })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            modifier = Modifier.weight(1f),
                            enabled = !running,
                            onClick = {
                                traces = emptyList()
                                engine.shoot(angle.toDouble(), power.toDouble())
                                running = true
                                message = "Simulating collisions and cushion response…"
                            }
                        ) { Text("SIMULATE SHOT") }
                        OutlinedButton(
                            modifier = Modifier.weight(1f),
                            onClick = {
                                running = false
                                engine.reset()
                                traces = emptyList()
                                frame++
                                message = "Board reset. Ready for another shot."
                            }
                        ) { Text("RESET") }
                    }
                }
            }
            Text(message, color = Color(0xFFB6C5C7), fontSize = 10.sp)
            Text("Independent practice simulator • Not connected to Miniclip or other games",
                color = Color(0xFF829395), fontSize = 9.sp)
        }
    }
}

@Composable
private fun CarromBoard(
    engine: CarromPhysics,
    traces: List<List<Vec>>,
    showPath: Boolean,
    angle: Float,
    modifier: Modifier
) {
    var redraw by remember { mutableIntStateOf(0) }
    Canvas(modifier) {
        redraw
        val side = min(size.width, size.height)
        val board = side * .96f
        val x0 = (size.width - board) / 2
        val y0 = (size.height - board) / 2
        val scale = board
        fun point(v: Vec) = Offset(x0 + v.x * scale, y0 + v.y * scale)
        drawRoundRect(
            Brush.linearGradient(listOf(Color(0xFF6B371D), Color(0xFFD49B5C), Color(0xFF8A4A25))),
            Offset(x0, y0), Size(board, board),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(board * .035f)
        )
        val a = board * .075f
        drawRect(Color(0xFFE8C997), Offset(x0+a, y0+a), Size(board-2*a, board-2*a))
        val b = board * .115f
        drawRect(Color(0xFFF4DDB6), Offset(x0+b, y0+b), Size(board-2*b, board-2*b),
            style = androidx.compose.ui.graphics.drawscope.Stroke(board*.007f))
        val corners = listOf(Vec(.10,.10),Vec(.90,.10),Vec(.10,.90),Vec(.90,.90))
        corners.forEach { drawCircle(Color(0xFF20140E), board*.043f, point(it)) }
        val c = point(Vec(.5,.5))
        drawCircle(Color(0xFF9E4636), board*.105f, c,
            style = androidx.compose.ui.graphics.drawscope.Stroke(board*.006f))
        drawLine(Color(0xFF9E4636), point(Vec(.30,.25)), point(Vec(.70,.25)), board*.006f)
        drawLine(Color(0xFF9E4636), point(Vec(.30,.75)), point(Vec(.70,.75)), board*.006f)

        if (showPath) {
            traces.forEach { path ->
                if (path.size > 1) {
                    val p = Path().apply {
                        moveTo(point(path.first()).x, point(path.first()).y)
                        path.drop(1).forEach { lineTo(point(it).x, point(it).y) }
                    }
                    drawPath(p, Color(0xAA168FA0), style = androidx.compose.ui.graphics.drawscope.Stroke(board*.003f))
                }
            }
        }

        engine.discs.forEach { d ->
            if (d.active) {
                val p = point(d.p)
                val r = board * engine.radius.toFloat()
                val color = when(d.type) {
                    CoinType.WHITE -> Color(0xFFF4EBDD)
                    CoinType.BLACK -> Color(0xFF28272A)
                    CoinType.RED -> Color(0xFFB51F2C)
                    CoinType.STRIKER -> Color(0xFF38BFD1)
                }
                drawCircle(Color(0x55000000), r*1.12f, p + Offset(1f,2f))
                drawCircle(color, r, p)
                drawCircle(Color(0x99FFFFFF), r*.72f, p,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(r*.10f))
            }
        }
        val striker = engine.discs.firstOrNull { it.type == CoinType.STRIKER && it.active }
        if (striker != null && striker.v.length() < .001) {
            val start = point(striker.p)
            val rad = Math.toRadians(angle.toDouble())
            val end = Offset(start.x + cos(rad).toFloat()*board*.24f,
                start.y - sin(rad).toFloat()*board*.24f)
            drawLine(Color(0xFF087F91), start, end, board*.004f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(board*.018f, board*.012f)))
        }
    }
    LaunchedEffect(engine, traces) {
        while (true) {
            redraw++
            delay(32)
        }
    }
}
