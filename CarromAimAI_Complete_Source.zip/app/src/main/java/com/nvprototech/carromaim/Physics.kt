package com.nvprototech.carromaim

import kotlin.math.*

data class Vec(var x: Double, var y: Double) {
    operator fun plus(o: Vec) = Vec(x + o.x, y + o.y)
    operator fun minus(o: Vec) = Vec(x - o.x, y - o.y)
    operator fun times(k: Double) = Vec(x * k, y * k)
    fun dot(o: Vec) = x * o.x + y * o.y
    fun length() = sqrt(x*x + y*y)
    fun normalized(): Vec { val l = length(); return if (l < 1e-9) Vec(0.0, 0.0) else Vec(x/l, y/l) }
}

enum class CoinType { WHITE, BLACK, RED, STRIKER }
data class Disc(
    val id: Int,
    val type: CoinType,
    var p: Vec,
    var v: Vec = Vec(0.0, 0.0),
    var active: Boolean = true
)

class CarromPhysics {
    val min = 0.10
    val max = 0.90
    val radius = 0.022
    private val restitution = 0.91
    private val wallRestitution = 0.82
    private val friction = 0.985
    private val stopSpeed = 0.004
    private val pocketCenters = listOf(
        Vec(min, min), Vec(max, min), Vec(min, max), Vec(max, max)
    )
    var discs = mutableListOf<Disc>()
        private set

    init { reset() }

    fun reset() {
        discs = mutableListOf(
            Disc(1, CoinType.RED, Vec(.50, .50)),
            Disc(2, CoinType.WHITE, Vec(.50, .454)),
            Disc(3, CoinType.BLACK, Vec(.54, .477)),
            Disc(4, CoinType.WHITE, Vec(.46, .477)),
            Disc(5, CoinType.BLACK, Vec(.54, .523)),
            Disc(6, CoinType.WHITE, Vec(.46, .523)),
            Disc(7, CoinType.BLACK, Vec(.50, .546)),
            Disc(8, CoinType.STRIKER, Vec(.50, .79))
        )
    }

    fun shoot(angleDegrees: Double, power: Double) {
        val striker = discs.firstOrNull { it.type == CoinType.STRIKER && it.active } ?: return
        val a = Math.toRadians(angleDegrees)
        val speed = 0.012 + power.coerceIn(0.0, 1.0) * 0.105
        striker.v = Vec(cos(a) * speed, -sin(a) * speed)
    }

    fun isMoving() = discs.any { it.active && it.v.length() > stopSpeed }

    fun step() {
        val active = discs.filter { it.active }
        // Integrate at a fixed simulation step.
        active.forEach { d ->
            d.p.x += d.v.x
            d.p.y += d.v.y
            d.v = d.v * friction
            if (d.v.length() < stopSpeed) d.v = Vec(0.0, 0.0)
            // Side rails: pockets are openings near each corner.
            if (d.p.x < min + radius || d.p.x > max - radius) {
                val nearCorner = d.p.y < min + .07 || d.p.y > max - .07
                if (!nearCorner) {
                    d.p.x = d.p.x.coerceIn(min + radius, max - radius)
                    d.v.x = -d.v.x * wallRestitution
                }
            }
            if (d.p.y < min + radius || d.p.y > max - radius) {
                val nearCorner = d.p.x < min + .07 || d.p.x > max - .07
                if (!nearCorner) {
                    d.p.y = d.p.y.coerceIn(min + radius, max - radius)
                    d.v.y = -d.v.y * wallRestitution
                }
            }
        }
        // Pairwise equal-mass disc collision resolution.
        for (i in active.indices) for (j in i + 1 until active.size) {
            val a = active[i]; val b = active[j]
            val delta = b.p - a.p
            val dist = delta.length()
            val minDist = radius * 2
            if (dist in 1e-8..minDist) {
                val n = delta * (1.0 / dist)
                val overlap = minDist - dist
                a.p = a.p - n * (overlap * .5)
                b.p = b.p + n * (overlap * .5)
                val rel = (b.v - a.v).dot(n)
                if (rel < 0) {
                    val impulse = -(1.0 + restitution) * rel / 2.0
                    a.v = a.v - n * impulse
                    b.v = b.v + n * impulse
                }
            }
        }
        // Pocket capture.
        active.forEach { d ->
            if (pocketCenters.any { (d.p - it).length() < .042 }) {
                d.active = false
                d.v = Vec(0.0, 0.0)
            }
        }
    }

    fun runSimulation(maxSteps: Int = 1800): List<List<Vec>> {
        val trace = mutableListOf<MutableList<Vec>>()
        discs.forEach { trace.add(mutableListOf(it.p.copy())) }
        repeat(maxSteps) {
            if (!isMoving()) return@repeat
            step()
            discs.forEachIndexed { index, d ->
                if (d.active && (it % 3 == 0)) trace[index].add(d.p.copy())
            }
        }
        return trace
    }
}
