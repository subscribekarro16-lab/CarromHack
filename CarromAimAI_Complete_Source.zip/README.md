# Carrom Aim AI — Complete standalone practice simulator

## Scope
This is an independent carrom practice simulator. It does not connect to, inspect,
overlay, automate, or modify Miniclip Carrom Pool or any other third-party game.

## Included
- Android Kotlin + Jetpack Compose project
- Wood-tone board with four pockets and board markings
- White, black, red coins and striker
- Adjustable shot angle and power
- Fixed-step-style animated simulation loop
- Disc collision response, friction, cushion rebounds and pocket capture
- Reset and trajectory display switch
- Offline operation

## Physics model
The simulation uses normalized board coordinates, equal-mass circular discs,
approximate restitution, velocity damping and corner pocket capture. It is a
starter educational model, not a calibrated match-grade solver. The current
trajectory display is reserved for path rendering; predictive path search and
computer-vision recognition are not included.

## Build from an Android phone
This project includes a GitHub Actions workflow. Upload the extracted project
to a GitHub repository from your phone browser, then open the Actions tab and
run the workflow. Download the `CarromAimAI-debug-apk` artifact after the
workflow succeeds. No local PC is required.

Alternatively open the project in a compatible Android cloud IDE/build service.
The source has not been compiled or tested on a physical device in this session.
